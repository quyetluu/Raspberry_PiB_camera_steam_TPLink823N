#ifndef NO_LIBJPEG
int compress_image_to_jpeg(struct vdIn *vd, unsigned char *buffer, int size, int quality);
#endif
